#!/bin/sh
#
# Copyright 2004-2021 Crypto-Pro. All rights reserved.
#
# This is proprietary information of
# Crypto-Pro company.
#
# Any part of this file can not be copied, 
# corrected, translated into other languages,
# localized or modified by any means,
# compiled, transferred over a network from or to
# any computer system without preliminary
# agreement with Crypto-Pro company
#
# ---------------------------------------------------
#
# This script installs root certificates
# 
# Usage:
#   install_roots.sh <path_to_JRE>
#
# Example:
#   install_roots.sh /usr/java/jre8
#

# how to
if [ -z "$1" ]; then
  printf "USAGE:\n"
  printf "   install_roots.sh path_to_JRE \n"
  printf " Example:\n"
  printf "   install_roots.sh /usr/java/jre8 \n"
  exit 1
fi

if [ $(id -u) != 0 ]; then
  echo "Root only accessed"
  exit 1   
  # need elevate script privileges
fi

printf "Params: $*\n"
CURRENT_PATH="`pwd`"

# check JVM
JREDIR=$1
KEYTOOL_CMD="$JREDIR/bin/keytool"
[ -x "$KEYTOOL_CMD" ] || {
  printf "File not found: $KEYTOOL_CMD\n"
  exit 1
}

printf "$CURRENT_PATH\n"

for f in "$CURRENT_PATH"/*.cer; do
  file=$(basename $f)
  $KEYTOOL_CMD -importcert -file $f -alias "${file}_root" -keystore "$JREDIR/lib/security/cacerts" -storepass changeit -noprompt
done